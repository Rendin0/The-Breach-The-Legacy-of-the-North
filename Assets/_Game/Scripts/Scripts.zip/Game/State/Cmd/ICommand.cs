
public interface ICommand
{

}