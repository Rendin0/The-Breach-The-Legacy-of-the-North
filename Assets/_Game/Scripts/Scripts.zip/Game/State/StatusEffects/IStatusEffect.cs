
public interface IStatusEffect
{
    public void Apply(CreatureViewModel creature);
}