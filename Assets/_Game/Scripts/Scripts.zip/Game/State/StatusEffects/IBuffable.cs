
public interface IBuffable
{
    public void AddStatusEffect(IStatusEffect effect);
    public void RemoveStatusEffect(IStatusEffect effect);

}