
using System;

[Serializable]
public class InventorySlotData
{
    public string ItemId = ItemsIDs.Nothing;
    public int Amount = 0;
}