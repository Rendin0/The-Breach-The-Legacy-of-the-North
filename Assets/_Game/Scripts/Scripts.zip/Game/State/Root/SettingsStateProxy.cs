
public class SettingsStateProxy
{
    public SettingsStateProxy(SettingsState settingsState)
    {

    }
}