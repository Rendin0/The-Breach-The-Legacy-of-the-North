
public interface IDamageable
{
    public bool Damage(float damage);
}
