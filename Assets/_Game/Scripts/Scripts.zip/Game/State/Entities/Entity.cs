using System;

[Serializable]
public abstract class Entity
{
    public int Id;
}