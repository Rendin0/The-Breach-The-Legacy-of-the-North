using System;

[Serializable]
public class DialogueChoiceData
{
    public string Text;
    public DialogueConfig NextDialogue;

}
