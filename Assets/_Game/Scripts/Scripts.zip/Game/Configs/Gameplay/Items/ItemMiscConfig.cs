
using UnityEngine;

[CreateAssetMenu(fileName = "ItemMiscConfig_", menuName = "Game Config/Items/New Misc Config")]

public class ItemMiscConfig : ItemConfig
{
    public override ItemType Type => ItemType.Misc;


}
