public static class Scenes
{
    public const string BOOT = "Boot";
    public const string GAMEPLAY = "Gameplay";
    public const string MAINMENU = "MainMenu";
}
