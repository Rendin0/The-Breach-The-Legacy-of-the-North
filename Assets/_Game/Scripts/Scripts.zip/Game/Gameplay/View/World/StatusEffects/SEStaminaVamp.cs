
public class SEStaminaVamp : IStatusEffect
{

    public void Apply(CreatureViewModel stats)
    {
        throw new System.NotImplementedException();
    }
}