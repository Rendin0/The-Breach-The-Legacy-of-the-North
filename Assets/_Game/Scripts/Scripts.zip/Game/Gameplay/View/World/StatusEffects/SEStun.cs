using UnityEngine;

public class SEStun : IStatusEffect
{
    public void Apply(CreatureViewModel creatue)
    {
        Debug.LogWarning("Stun status effect is not implemented");
    }
}