
public class PopupDialogueBinder : PopupBinder<PopupDialogueViewModel>
{

}
