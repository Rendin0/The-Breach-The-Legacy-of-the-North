
public class PopupDialogueViewModel : WindowViewModel
{
    public override string Id => "PopupDialogue";


    public PopupDialogueViewModel()
    {
    }
}
