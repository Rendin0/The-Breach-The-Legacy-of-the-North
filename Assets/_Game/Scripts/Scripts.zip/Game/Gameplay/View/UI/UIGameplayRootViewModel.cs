public class UIGameplayRootViewModel : UIRootViewModel
{
    public UIGameplayRootViewModel(InputRequests inputRequests)
        : base(inputRequests)
    {
    }
}
