
using System.Collections.Generic;
using UnityEngine;

public class InventoryPageBinder : MonoBehaviour
{
    public List<InventorySlotBinder> Slots;

}