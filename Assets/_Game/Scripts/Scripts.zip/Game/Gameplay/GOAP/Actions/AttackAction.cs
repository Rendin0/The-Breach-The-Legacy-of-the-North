
using CrashKonijn.Agent.Core;
using CrashKonijn.Goap.Runtime;

public class AttackAction : GoapActionBase<AttackAction.Data>
{
    public override void Start(IMonoAgent agent, Data data)
    {
        data.ViewModel = agent.GetComponent<CreatureBinder>().ViewModel;
        
    }

    public override IActionRunState Perform(IMonoAgent agent, Data data, IActionContext context)
    {
        bool result = data.ViewModel.Attack(data.ViewModel.CurrentTarget.Position.Value);

        return result ? ActionRunState.Completed : ActionRunState.Stop;
    }

    public class Data : ActionData
    {
        public CreatureViewModel ViewModel { get; set; }
    }
}
