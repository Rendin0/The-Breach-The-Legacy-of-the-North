
using CrashKonijn.Goap.Runtime;

public class IdleGoal : GoalBase
{

}