using CrashKonijn.Goap.Runtime;

public class KillEnemyGoal : GoalBase { }