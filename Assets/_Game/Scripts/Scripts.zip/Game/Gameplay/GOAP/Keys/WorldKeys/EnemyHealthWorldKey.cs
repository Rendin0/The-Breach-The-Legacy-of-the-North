
using CrashKonijn.Goap.Runtime;

public class EnemyHealthWorldKey : WorldKeyBase
{

}