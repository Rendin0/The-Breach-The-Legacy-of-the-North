
using CrashKonijn.Goap.Runtime;

public class EnemyTargetKey : TargetKeyBase
{

}