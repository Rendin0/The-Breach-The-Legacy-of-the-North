
using CrashKonijn.Goap.Runtime;

public class IdleTargetKey : TargetKeyBase
{ }