public class PopupSettingsViewModel : WindowViewModel
{
    public override string Id => "PopupSettings";
}