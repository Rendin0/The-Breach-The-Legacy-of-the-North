
public class PopupSettingsBinder : PopupBinder<PopupSettingsViewModel>
{

}