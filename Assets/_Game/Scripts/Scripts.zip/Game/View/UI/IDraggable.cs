using UnityEngine.EventSystems;

public interface IDraggable : IPointerDownHandler, IPointerUpHandler
{
}