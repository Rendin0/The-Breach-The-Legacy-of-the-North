using UnityEngine.EventSystems;

public interface IElementInfoBinder : IPointerEnterHandler, IPointerExitHandler
{

}

