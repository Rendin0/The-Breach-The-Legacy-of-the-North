public class UIMainMenuRootBinder : UIRootBinder
{

}
