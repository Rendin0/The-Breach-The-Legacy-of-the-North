public class UIMainMenuRootViewModel : UIRootViewModel
{
    public UIMainMenuRootViewModel(InputRequests inputRequests)
        : base(inputRequests)
    {
    }
}