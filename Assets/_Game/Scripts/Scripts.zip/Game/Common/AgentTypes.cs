public enum AgentTypes
{
    None,
    PigAgent,
}