
public static class AppConstants
{
    public const string EXIT_SCENE_REQUEST_TAG = nameof(EXIT_SCENE_REQUEST_TAG);
    public const string GAMEPLAY_REQUESTS = nameof(GAMEPLAY_REQUESTS);
    public const string MAINMENU_REQUESTS = nameof(MAINMENU_REQUESTS);
}