
public static class CreaturesTypes
{
    public const string Player = nameof(Player);
}
