
public static class StarSizes
{
    public const string Small = nameof(Small);
    public const string Large = nameof(Large);
}