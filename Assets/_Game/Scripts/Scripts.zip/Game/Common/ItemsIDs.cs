
public static class ItemsIDs
{
    public const string Nothing = nameof(Nothing);
}