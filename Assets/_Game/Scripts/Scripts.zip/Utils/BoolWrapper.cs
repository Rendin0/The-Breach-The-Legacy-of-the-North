
public class BoolWrapper
{
    public bool Value { get; set; } = true;
}