public enum DSDialogueType
{
    SingleChoice,
    MultipleChoice
}
